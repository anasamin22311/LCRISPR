run this 

python.exe crispr.py -i queryTest.csv -o outQueryTest.csv -s 21 -p 3 -l NGG